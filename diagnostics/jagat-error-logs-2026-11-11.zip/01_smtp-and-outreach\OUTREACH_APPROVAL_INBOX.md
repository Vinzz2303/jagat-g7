# JAGAT Outreach Approval Inbox

Generated: 2026-11-11 19:31
Mode: review founder; satu approval exact per pesan; sender memproses maksimal satu pesan per siklus

## Prinsip
- JAGAT boleh mencari prospek, menilai prioritas, dan membuat draft.
- JAGAT tidak mengirim email tanpa approval founder yang mengikat alamat dan hash isi pesan.
- Tanpa approval, jadwal hanya mencari prospek, membuat draft, dan mengirim laporan Telegram.
- Maksimal 5 percobaan per hari; bulk outreach tetap dilarang.

## Siap Review Hari Ini
### 1. Daun Ketumbar Catering
- Email: csdaunketumbar@gmail.com
- Niche: catering
- Offer: AI Admin Bot
- Problem hypothesis: Permintaan paket dan event dapat dibantu dengan FAQ serta intake inquiry; kebutuhan perlu dikonfirmasi.
- Source: official_site:https://www.daunketumbar.com/
- Draft hash: 0aee1e677a74016ee8c8a4e576687d45783a15b319a507dc50f88ea0264f2743
- Approval action: APPROVE_ONE_SEND / SKIP / NEEDS_RESEARCH
### 2. Nanjing Aochuan Import and Export Co., Ltd
- Email: quantao088@gmail.com
- Niche: logistics
- Offer: Internal Command Center
- Problem hypothesis: Bisnis logistics punya kontak email publik; cocok untuk outreach profesional tentang AI admin dan workflow digital.
- Source: puppeteer_discovery:https://www.indonesiayp.com/company/840340/nanjing-aochuan-import-and-export-co-ltd
- Draft hash: 2ddf5bd5f8bf3e358cc5d6bb0f975a9811f3af6f5825cd586f3ab9de0255bc66
- Approval action: APPROVE_ONE_SEND / SKIP / NEEDS_RESEARCH
### 3. Angkutan Utama Perkasa PT
- Email: adm.market@aup.co.id
- Niche: logistics
- Offer: Internal Command Center
- Problem hypothesis: Bisnis logistics punya kontak email publik; cocok untuk outreach profesional tentang AI admin dan workflow digital.
- Source: puppeteer_discovery:https://www.indonesiayp.com/company/657513/Angkutan_Utama_Perkasa_PT
- Draft hash: 9f6a241d14926579a0b3ade09c695accfbedd8453fd72868a136a437b7542bad
- Approval action: APPROVE_ONE_SEND / SKIP / NEEDS_RESEARCH
### 4. Gaido Cito Ekakurindo. PT (Gaido Express & Logistics)
- Email: express.gaido@gmail.com
- Niche: logistics
- Offer: Internal Command Center
- Problem hypothesis: Bisnis logistics punya kontak email publik; cocok untuk outreach profesional tentang AI admin dan workflow digital.
- Source: puppeteer_discovery:https://www.indonesiayp.com/company/418330/Gaido_Cito_Ekakurindo_PT_Gaido_Express_LogisticsPekanbaru
- Draft hash: 46a7cc9abec12d1865569d425fd2623e7eb863f7c0a72f19c80132aa025b68d1
- Approval action: APPROVE_ONE_SEND / SKIP / NEEDS_RESEARCH
### 5. PT. Puri Luhut
- Email: rantolubis@gmail.com
- Niche: logistics
- Offer: Internal Command Center
- Problem hypothesis: Bisnis logistics punya kontak email publik; cocok untuk outreach profesional tentang AI admin dan workflow digital.
- Source: puppeteer_discovery:https://www.indonesiayp.com/company/837046/PT_Puri_Luhut
- Draft hash: f8f62e9be6dc79a1f07b5f2714ef0262c1a2ff9b2a2f9722874db626e782cb38
- Approval action: APPROVE_ONE_SEND / SKIP / NEEDS_RESEARCH

## Setelah Approval / Balasan
- Update `response` jika ada balasan.
- Update `follow_up_due` untuk follow-up 24/48 jam.
- Jangan follow-up jika prospek menolak.