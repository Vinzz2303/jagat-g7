# Email Prospect Discovery Report

Generated: 2026-11-12T00:45:13.419Z
Mode: Puppeteer + DNS MX Validation (High Quality)
Source queue: 340 category/city sources, next index 240
Scanned: gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; gym-fitness: page 2, 0 urls; photography: page 2, 0 urls; photography: page 2, 0 urls
Explored pages: gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, gym-fitness p2, photography p2, photography p2
Inspected company pages: 0
New email leads: 0
New leads appended: 0

## New Leads
No email-ready prospects found in this cycle.

## Safety
Puppeteer browsing was used. Dead domains were filtered using MX validation.